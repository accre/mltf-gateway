#!/bin/bash
echo "Hello World"
sleep 2
date >> restart.log
exit 0
